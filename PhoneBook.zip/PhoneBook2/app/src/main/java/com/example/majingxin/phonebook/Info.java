package com.example.majingxin.phonebook;




import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Info extends Activity {
    public final static String BOOKNAME="phonebook2";
    public final static String ID="id";
    public final static String NAME="name";
    public final static String PHONE="phone";
    public final static String JOB="job";
    public final static String AREA="area";
    public final static String EMAIL="email";
    public final static String GROUP="qunzu";
    public final static String COLLECT="collect";
    MyDatabase mydb;
    Cursor cur;
    TextView t1,t2,t3,t4,t5,t6,t7,t8;
    Button b1,b2;
    int a=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info);

        t1=findViewById(R.id.textView1);
        t2=findViewById(R.id.textView2);
        t3=findViewById(R.id.textView3);
        t4=findViewById(R.id.textView4);
        t5=findViewById(R.id.textView5);
        t6=findViewById(R.id.textView6);
        t7=findViewById(R.id.textView7);
        t8=findViewById(R.id.textView8);
        b1=findViewById(R.id.button1);
        b2=findViewById(R.id.button2);

        //接收主页传来值
        Intent in=getIntent();
        Bundle bundle=in.getExtras();
        a=bundle.getInt("k1");

//	Toast.makeText(Info.this,a+" ", Toast.LENGTH_LONG).show();

        //获取数据库数据
        mydb=new MyDatabase(this);
        cur=mydb.select();
        cur.moveToPosition(a);
        String id=cur.getString(cur.getColumnIndex(ID));
        String name=cur.getString(cur.getColumnIndex(NAME));
        String phone=cur.getString(cur.getColumnIndex(PHONE));
        String job=cur.getString(cur.getColumnIndex(JOB));
        String email=cur.getString(cur.getColumnIndex(EMAIL));
        String area=cur.getString(cur.getColumnIndex(AREA));
        String group=cur.getString(cur.getColumnIndex(GROUP));
        int collect=cur.getInt(cur.getColumnIndex(COLLECT));

        //   Toast.makeText(Info.this, id+name+phone+job+email+area+group+collect, Toast.LENGTH_LONG).show();
        //给页面文本框赋值
        t1.setText(id);
        t2.setText(name);
        t3.setText(phone);
        t4.setText(job);
        t5.setText(email);
        t6.setText(area);
        t7.setText(group);
        if(collect==0){
            t8.setText("未收藏");
        }
        else if(collect==1){
            t8.setText("收藏");
        }
        //修改信息按钮
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Intent in3=new Intent();
                in3.setClass(Info.this, Update.class);
                Bundle bundle2=new Bundle();
                bundle2.putInt("k2", a);
                in3.putExtras(bundle2);
                startActivity(in3);
            }
        });

        //返回主页按钮
        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Intent in0=new Intent();
                in0.setClass(Info.this, MainActivity.class);
                startActivity(in0);
            }
        });

    }
}
