package com.example.majingxin.phonebook;

import java.util.ArrayList;
import java.util.List;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class Add extends AppCompatActivity {
    EditText e_name;
    EditText e_job;
    EditText e_phone;
    EditText e_email;
    Spinner sp;
    List<String> list;
    RadioGroup radio_group;
    CheckBox c1,c2,c3,c4;
    Button b_cancel;
    Button b_add;
    int collect;
    String group="";
    ArrayAdapter adapter;
    MyDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add);
        e_name=findViewById(R.id.editText1);
        e_job=findViewById(R.id.editText2);
        e_phone=findViewById(R.id.editText3);
        e_email=findViewById(R.id.editText4);
        sp=findViewById(R.id.sp1);
        radio_group=findViewById(R.id.RadioG);
        c1=findViewById(R.id.checkBox);
        c2=findViewById(R.id.checkBox2);
        c3=findViewById(R.id.checkBox3);
        c4=findViewById(R.id.checkBox4);
        b_cancel=findViewById(R.id.button);
        b_add=findViewById(R.id.button2);
        //设置下拉列表的初始值
        list=new ArrayList<String>();
        list.add("地区");
        list.add("北京");
        list.add("广州");
        list.add("上海");
        list.add("四川");
        list.add("辽宁");
        list.add("新疆维吾尔族自治区");
        list.add("宁夏回族自治区");
        list.add("山东");
        list.add("重庆");
        list.add("黑龙江");
        list.add("吉林");
        adapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,list);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        sp.setAdapter(adapter);
        //
        mydb=new MyDatabase(this);
        b_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in1=new Intent();
                in1.setClass(Add.this,MainActivity.class);
                startActivity(in1);
            }
        });

        //添加
        b_add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                //Toast.makeText(Add.this, "111", Toast.LENGTH_LONG).show();

                String name=e_name.getText().toString();
                String phone=e_phone.getText().toString();
                String job=e_job.getText().toString();
                String email=e_email.getText().toString();
                collect=0;

                // 单选按钮处理

                collect=radio_group.getCheckedRadioButtonId();
                if (collect==R.id.radioButton){
                    collect=0;
                }
                if (collect==R.id.radioButton2){
                    collect=1;
                }


                //复选按钮处理


                if(c1.isChecked()){
                    group=group+"家人";
                }
                if(c2.isChecked()){
                    group=group+"同事";
                }
                if(c3.isChecked()){
                    group=group+"同学";
                }
                if(c4.isChecked()){
                    group=group+"客户";
                }


                //获取下拉列表的值
                String area= sp.getSelectedItem().toString();



                //    Toast.makeText(Add.this,name+phone+job+email+area+"信息内容"+group+collect,Toast.LENGTH_LONG).show();



                //添加
                mydb.insert(name,phone,job,email,area,group,collect);


                Toast.makeText(Add.this,"添加成功",Toast.LENGTH_LONG).show();
                Intent in=new Intent();
                in.setClass(Add.this, MainActivity.class);
                startActivity(in);

            }

        });

    }
}
