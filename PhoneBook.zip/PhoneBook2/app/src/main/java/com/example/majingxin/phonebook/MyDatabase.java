package com.example.majingxin.phonebook;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class MyDatabase {
	public final static String TABLENAME="phonebook2";
	public final static String ID="id";
	public final static String NAME="name";
	public final static String PHONE="phone";
	public final static String JOB="job";
	public final static String AREA="area";
	public final static String EMAIL="email";
	public final static String GROUP="qunzu";
	public final static String COLLECT="collect";

	MySQLite mySQLite;
	SQLiteDatabase db;
	Cursor cursor;
	public MyDatabase(Context context) {
		mySQLite=new MySQLite(context);
		db=mySQLite.getWritableDatabase();
	}

	//增
	public void insert(String name,String phone,String job,String email,String area,String group,int collect){
		System.out.println("===insert===111===");

		String sql="insert into "+TABLENAME+"("+NAME+","+PHONE+","+JOB+","+EMAIL+","+AREA+","+GROUP+","+COLLECT+") values(?,?,?,?,?,?,?)";
		System.out.println("sql--->>> "+sql);
		System.out.println(name+" "+phone+" "+job+" "+email+" "+area+" "+group+" "+collect);
		db.execSQL(sql,new Object[]{name,phone,job,email,area,group,collect});
		System.out.println("===insert===2222===");

	}
	//删
	public void delete(String name,String phone){
		String sql="delete from "+TABLENAME+" where "+NAME+"=? and "+PHONE+"=?";
		db.execSQL(sql,new Object[]{name,phone});
	}
	//改
	public void update(int id,String name,String phone,String job,String email,String area,String group,int collect){
		System.out.println("----===updatazhong---===");
		System.out.println(id+name+phone+job+email+area+group+collect);
		String sql="update "+TABLENAME+" set "+NAME+"=? , "+PHONE+"=? , "+JOB+"=? , "+EMAIL+" = ? , "+AREA+"=? , "+GROUP+"=? , "+COLLECT+"=? where "+ID+"=?";
		db.execSQL(sql,new Object[]{name,phone,job,email,area,group,collect,id});

	}
	//查
	public Cursor select(){
		System.out.println("====1=1=1=1=");
		cursor=db.query(TABLENAME,null,null,null,null,null,null);
		System.out.println("0000101010101");
		return cursor;
	}
	//模糊查询 姓名
	public  Cursor selectlikename(String name){
		String sql=NAME+" like '%"+name+"%' ";
		cursor=db.query(TABLENAME,null,sql,null,null,null,null);
		return cursor;
	}
}
