package com.example.majingxin.phonebook;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class MySQLite extends SQLiteOpenHelper {
	

		public final static String TABLENAME="phonebook2";
	    public final static String ID="id";
	    public final static String NAME="name";
	    public final static String PHONE="phone";
	    public final static String JOB="job";
	    public final static String EMAIL="email";
	    public final static String AREA="area";
	    public final static String GROUP="qunzu";
	    public final static String COLLECT="collect";
		private final static String DATABASENAME="MJX.db";
	
	    public MySQLite(Context context) {
	        super(context, DATABASENAME, null, 1);
			// TODO Auto-generated constructor stub
		}
	@Override
	public void onCreate(SQLiteDatabase arg0) {

		String sql="create table if not exists "+TABLENAME+"("
				+ID+" integer primary key autoincrement ,"
				+NAME+" text(20),"
				+PHONE+" text(20),"
				+JOB+" text(20),"
				+EMAIL+" text(20),"
				+AREA+" text(20),"
				+GROUP+" text(20),"
				+COLLECT+" integer )";
		arg0.execSQL(sql);

	}
	
	

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
		// TODO Auto-generated method stub

	}

}
