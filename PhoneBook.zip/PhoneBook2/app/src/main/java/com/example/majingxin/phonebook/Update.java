package com.example.majingxin.phonebook;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class Update extends AppCompatActivity {
    public final static String BOOKNAME="phonebook2";
    public final static String ID="id";
    public final static String NAME="name";
    public final static String PHONE="phone";
    public final static String JOB="job";
    public final static String AREA="area";
    public final static String EMAIL="email";
    public final static String GROUP="qunzu";
    public final static String COLLECT="collect";
    int a=0;
    EditText e_name;
    EditText e_job;
    EditText e_phone;
    EditText e_email;
    Spinner sp;
    RadioGroup radio_group;
    RadioButton radio1,radio2;
    CheckBox c1,c2,c3,c4;
    Button b_add;
    Button b_cancel;
    MyDatabase mydb;
    Cursor cur;
    List<String> list;
    //    ArrayAdapter adapter;
    int collect1=0;
    int id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add);
        e_name=findViewById(R.id.editText1);
        e_job=findViewById(R.id.editText2);
        e_phone=findViewById(R.id.editText3);
        e_email=findViewById(R.id.editText4);
        sp=findViewById(R.id.sp1);
        radio_group=findViewById(R.id.RadioG);
        radio1=findViewById(R.id.radioButton);
        radio2=findViewById(R.id.radioButton2);
        c1=findViewById(R.id.checkBox);
        c2=findViewById(R.id.checkBox2);
        c3=findViewById(R.id.checkBox3);
        c4=findViewById(R.id.checkBox4);
        b_cancel=findViewById(R.id.button);
        b_add=findViewById(R.id.button2);
        b_add.setText("修改");

        //接收主页传来值
        Intent in=getIntent();
        Bundle bundle=in.getExtras();
        a=bundle.getInt("k2");

        //	Toast.makeText(Update.this,a+"", Toast.LENGTH_LONG).show();

        //获取数据库数据
        mydb=new MyDatabase(this);
        cur=mydb.select();
        cur.moveToPosition(a);
        id=cur.getInt(cur.getColumnIndex(ID));
        String name=cur.getString(cur.getColumnIndex(NAME));
        String phone=cur.getString(cur.getColumnIndex(PHONE));
        String job=cur.getString(cur.getColumnIndex(JOB));
        String email=cur.getString(cur.getColumnIndex(EMAIL));
        String area=cur.getString(cur.getColumnIndex(AREA));
        String group=cur.getString(cur.getColumnIndex(GROUP));
        int collect=cur.getInt(cur.getColumnIndex(COLLECT));

        //初始化页面值
        e_name.setText(name);
        e_job.setText(job);
        e_phone.setText(phone);
        e_email.setText(email);
        if(collect==0){
            radio_group.check(radio1.getId());
        }
        else if(collect==1){
            radio_group.check(radio2.getId());
        }
        //复选框赋值
        //拆分
        String[] strs = new String[group.length()-1];
        for(int i=0;i<group.length()-1;i++){
            strs[i] = group.substring(i, i+2);
            if(strs[i].equals(c1.getText().toString())){
                c1.setChecked(true);
            }
            if(strs[i].equals(c2.getText().toString())){
                c2.setChecked(true);
            }
            if(strs[i].equals(c3.getText().toString())){
                c3.setChecked(true);
            }
            if(strs[i].equals(c4.getText().toString())){
                c4.setChecked(true);
            }
        }
//        c2.setChecked(true);
//        c4.setChecked(true);
        //设置下拉列表的初始值
        list=new ArrayList<String>();
        list.add(area);
        list.add("北京");
        list.add("广州");
        list.add("上海");
        list.add("四川");
        list.add("辽宁");
        list.add("新疆维吾尔族自治区");
        list.add("宁夏回族自治区");
        list.add("山东");
        list.add("重庆");
        list.add("黑龙江");
        list.add("吉林");
        ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,list);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        sp.setAdapter(adapter);


        //点击修改
        b_add.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                //Toast.makeText(Add.this, "111", Toast.LENGTH_LONG).show();

                String name1=e_name.getText().toString();
                String phone1=e_phone.getText().toString();
                String job1=e_job.getText().toString();
                String email1=e_email.getText().toString();
                collect1=0;

                // 单选按钮处理

                collect1=radio_group.getCheckedRadioButtonId();
                if (collect1==R.id.radioButton){
                    collect1=0;
                }
                if (collect1==R.id.radioButton2){
                    collect1=1;
                }


                //复选按钮处理
                String group1="";

                if(c1.isChecked()){
                    group1=group1+"家人";
                }
                if(c2.isChecked()){
                    group1=group1+"同事";
                }
                if(c3.isChecked()){
                    group1=group1+"同学";
                }
                if(c4.isChecked()){
                    group1=group1+"客户";
                }
                //获取下拉列表的值
                String area1= sp.getSelectedItem().toString();

                System.out.println("====a===11 "+a);
                //修改
                mydb.update(id,name1, phone1, job1, email1, area1, group1, collect1);

                Toast.makeText(Update.this,"修改成功",Toast.LENGTH_LONG).show();

                Intent in66=new Intent();
                in66.setClass(Update.this,MainActivity.class);
                startActivity(in66);

            }

        });




        //修改结束

        //返回按钮
        b_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in11=new Intent();
                in11.setClass(Update.this,MainActivity.class);
                startActivity(in11);
            }
        });
        //返回按钮结束
    }


}
