package com.example.majingxin.phonebook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    public final static String BOOKNAME="phonebook2";
    public final static String ID="id";
    public final static String NAME="name";
    public final static String PHONE="phone";
    public final static String JOB="job";
    public final static String AREA="area";
    public final static String EMAIL="email";
    public final static String GROUP="qunzu";
    public final static String COLLECT="collect";
    MyDatabase mydb;
    Cursor cur;
    ListView listview ;
    ArrayList<Map<String, Object>> data  ;
    ArrayList<Map<String, Object>> data2  ;
    SimpleAdapter ada;
    EditText e_find;
    Button b_find;
    int k=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mydb=new MyDatabase(this);
        cur=mydb.select();
        listview = findViewById(R.id.listView1);
        e_find=findViewById(R.id.editText10);
        b_find=findViewById(R.id.button10);

        data=new ArrayList<Map<String,Object>>();
        if(cur.moveToFirst()){
            do{
                Map<String,Object> map=new HashMap<String,Object>();
                map.put("name", cur.getString(cur.getColumnIndex(NAME)));
                data.add(map);
            }while(cur.moveToNext());
        }
        String[] from={"name"};
        int[] to={R.id.textView2};
        ada=new SimpleAdapter(MainActivity.this, data, R.layout.listview_item, from, to);
        listview.setAdapter(ada);
        //初始化结束
        //点击跳转
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                // TODO Auto-generated method stub
                k=arg2;
                //		Toast.makeText(MainActivity.this, k+"===", Toast.LENGTH_LONG).show();
                Intent in21=new Intent();
                in21.setClass(MainActivity.this, Info.class);
                Bundle bundle=new Bundle();
                bundle.putInt("k1", arg2);
                in21.putExtras(bundle);
                startActivity(in21);
            }
        });
        //长按选项
//--------------
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,
                                           int arg2, long arg3) {
                // TODO Auto-generated method stub
                k=arg2;
                //	Toast.makeText(MainActivity.this, k+"===", Toast.LENGTH_LONG).show();

                AlertDialog.Builder dialog1=new AlertDialog.Builder(MainActivity.this);
                dialog1.setTitle("删除提示");
                dialog1.setMessage("你确认删除该条联系人吗？");
                dialog1.setNegativeButton("取消", null);
                dialog1.setPositiveButton("删除", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        // TODO Auto-generated method stub
                        cur.moveToPosition(k);
                        String name=cur.getString(cur.getColumnIndex(NAME));
                        String phone=cur.getString(cur.getColumnIndex(PHONE));
                        //		Toast.makeText(MainActivity.this, name+phone, Toast.LENGTH_LONG).show();
                        mydb.delete(name, phone);
                        data.remove(k);
                        listview.setAdapter(ada);
//						Intent in=new Intent();
//						in.setClass(MainActivity.this, MainActivity.class);
//						startActivity(in);
                    }
                });
                dialog1.show();

                return false;

            }

        });

//============
        //模糊查询
        b_find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String find_name=e_find.getText().toString();
                cur=mydb.selectlikename(find_name);
                data2=new ArrayList<Map<String,Object>>();
                if(cur.moveToFirst()){
                    do{
                        Map<String,Object> map=new HashMap<String,Object>();
                        map.put("name", cur.getString(cur.getColumnIndex(NAME)));
                        data2.add(map);
                    }while(cur.moveToNext());
                }
                String[] from={"name"};
                int[] to={R.id.textView2};
                ada=new SimpleAdapter(MainActivity.this, data2, R.layout.listview_item, from, to);
                listview.setAdapter(ada);

            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //   getMenuInflater().inflate(R.menu.main, menu);
        menu.add(0,1,0,"添加联系人");
        menu.add(0,2,0,"第二项");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        if(item.getItemId()==1){
            Intent in=new Intent();
            in.setClass(MainActivity.this,Add.class);
            startActivity(in);
        }
        return true;
    }
}
